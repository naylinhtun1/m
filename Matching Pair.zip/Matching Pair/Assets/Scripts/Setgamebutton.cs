﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Setgamebutton : MonoBehaviour
{
    public enum ButtonType
    {
        NotSet,
        Pairnumberbtn,
        Puzzlecategorybtn,
    }

    [SerializeField] public ButtonType buttonType = ButtonType.NotSet;
    [HideInInspector] public Gamesetting.PairNumber pairNumber = Gamesetting.PairNumber.NotSet;
    [HideInInspector] public Gamesetting.Puzzlecategories puzzlecategories = Gamesetting.Puzzlecategories.NotSet;

    private void Start()
    {
        
    }

    public void SetGameOption(string GameSceneName)
    {
        var comp = gameObject.GetComponent<Setgamebutton>();

        switch (comp.buttonType)
        {
            case Setgamebutton.ButtonType.Pairnumberbtn:
                Gamesetting.Instance.SetPairNumber(comp.pairNumber);
                break;
            case ButtonType.Puzzlecategorybtn:
                Gamesetting.Instance.SetPuzzleCategories(comp.puzzlecategories);
                break;
        }
        if (Gamesetting.Instance.AllSettingReady())
        {
            SceneManager.LoadScene(GameSceneName);
        }
    }
}
