﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(Setgamebutton))]
[CanEditMultipleObjects]
[System.Serializable]
public class Setgamebuttoneditor : Editor

{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();
        Setgamebutton myScript = target as Setgamebutton;
        switch (myScript.buttonType)
        {
            case Setgamebutton.ButtonType.Pairnumberbtn:
                myScript.pairNumber = (Gamesetting.PairNumber)EditorGUILayout.EnumPopup("pair Numbers", myScript.pairNumber);
                    break;
            case Setgamebutton.ButtonType.Puzzlecategorybtn:
                myScript.puzzlecategories = (Gamesetting.Puzzlecategories)EditorGUILayout.EnumPopup("puzzle categories", myScript.puzzlecategories);
                break;
        }
        if (GUI.changed)
        {
            EditorUtility.SetDirty(target);
        }
    }
}
